import random
import threading
import serial
import time
import tkinter as tk
import random
from tkinter import messagebox

ser = serial.Serial('COM8', 9600, timeout=0.25)
print(ser.name)

correctGuesses = []
global last_guess


def writeToBoard(phrase):
    ser.write(phrase.encode("utf-8"))
    time.sleep(0.1)


def scrambleToLCD(word):
    scrambled_word = ''.join(['_' if letter not in correctGuesses else letter for letter in word])
    # need to add padding to the word so that we can display on LCD
    padded_scrambled_word = scrambled_word.ljust(16, ' ')
    padded_scrambled_word
    # if scrambled_word == word:
    #     scrollMessage("                Well done! You have solved N puzzles out of M.                        ")
    #     newGamePrompt()
    return padded_scrambled_word[::-1]


def scrollMessage(message):
    reversed_message = message
    num_scrolls = len(reversed_message) - 16 + 1

    for i in range(num_scrolls):
        display_part = reversed_message[i:i + 16]
        display_part = display_part.ljust(16, ' ')
        writeToBoard(display_part[::-1])
        time.sleep(0.5)


# Method to load words from dictionary.txt
def load_words():
    with open('dictionary.txt', 'r') as file:
        allWords = [word.strip().lower() for word in file.readlines()]
        return allWords

    # Method to count the number of words in dictionary.txt


def count_words(self):
    with open('dictionary.txt', 'r') as file:
        return len(file.readlines())


# Class for the initial game prompt
class HangmanGame:
    def __init__(self, master, NumSuccessfulGuesses, List_With_Removed_Words, words):
        self.NumSuccessfulGuesses = NumSuccessfulGuesses
        self.master = master
        self.master.title("Hangman Game")
        self.words = words  # List to store words from dictionary.txt
        self.NumofWords = count_words(
            self)  # len(self.words)  # Variable to store the number of words in dictionary.txt
        self.new_game_prompt()
        self.List_With_Removed_Words = List_With_Removed_Words
        # self.NumofWords = self.count_words()  # Variable to store the number of words in dictionary.txt
        self.correctly_guessed_words = []  # List to store correctly guessed words
        print(self.words)

        self.serial_input_thread = threading.Thread(target=self.listen_for_serial_input)
        self.serial_input_thread.start()

    # Method to create the initial game prompt
    def new_game_prompt(self):
        self.message_label = tk.Label(self.master, text="New Game? (y/n)", font=('Arial', 18))
        self.message_label.pack()

        self.entry = tk.Entry(self.master, font=('Arial', 18))
        self.entry.pack()

        self.confirm_button = tk.Button(self.master, text="Confirm", command=self.start_game, font=('Arial', 18))
        self.confirm_button.pack()

    # Method to start the game
    def start_game(self):
        response = self.entry.get().lower()
        if response == 'y':
            self.master.destroy()  # Close the current GUI window
            root = tk.Tk()  # Open a new GUI window for the game
            hangman_game = HangmanGameWindow(root, self.NumSuccessfulGuesses, self.words, self.NumofWords,
                                             self.List_With_Removed_Words)
            root.mainloop()
        else:
            self.NumSuccessfulGuesses = 0
            self.master.destroy()
            self.master.quit()  # Close the application
            HangmanGameWindow.endGame(self)

    def listen_for_serial_input(self):
        while True:
            if ser.in_waiting > 0:
                response = ser.read(1).decode("utf-8")
                self.handle_serial_input(response)
            time.sleep(0.01)

    # function to essentially simulate entering a letter when the letter comes from the FPGA
    def handle_serial_input(self, response):
        if response.lower() in ['y', 'n']:
            self.entry.insert(0, response)
            self.start_game()


# Class for the main game window
class HangmanGameWindow:
    def __init__(self, master, NumSuccessfulGuesses, words, NumofWords, List_With_Removed_Words):
        self.master = master
        self.master.title("Hangman Game")  # Set window title
        self.words = words  # List to store words from dictionary.txt
        self.NumofWords = count_words(self)

        # Initialize game parameters
        self.NumSuccessfulGuesses = NumSuccessfulGuesses  # Store the number of successful guesses
        self.List_With_Removed_Words = List_With_Removed_Words
        self.word = self.select_word()
        print("about to write to word")
        self.guesses = ['_'] * len(self.word)
        self.remaining_guesses = 6
        self.guessed_letters = set()

        # initialize the LCD and 7-seg
        writeToBoard(scrambleToLCD(self.word) + str(self.remaining_guesses))

        self.serial_input_thread = threading.Thread(target=self.listen_for_serial_input)
        self.serial_input_thread.start()

        # Create GUI elements
        self.word_label = tk.Label(self.master, text=' '.join(self.guesses), font=('Arial', 24))
        self.word_label.pack()

        self.guess_entry = tk.Entry(self.master, font=('Arial', 18))
        self.guess_entry.pack()

        self.guess_button = tk.Button(self.master, text="Guess", command=self.check_guess, font=('Arial', 18))
        self.guess_button.pack()

        self.message_label = tk.Label(self.master, text='', font=('Arial', 18))
        self.message_label.pack()

        self.guessed_label = tk.Label(self.master, text='Guessed Letters: ', font=('Arial', 18))
        self.guessed_label.pack()

        # Set up canvas for drawing
        self.canvas = tk.Canvas(self.master, width=400, height=400, bg='white')
        self.canvas.pack()

    def endGame(self):
        mes1 = " " + str(self.NumSuccessfulGuesses) + " correct of " + str(self.NumofWords) + " "
        writeToBoard(mes1[::-1])
        time.sleep(5)
        mes2 = " GAME OVER        "
        writeToBoard(mes2[::-1])


        # Listen for input from FPGA
    def listen_for_serial_input(self):
        while True:
            if ser.in_waiting > 0:
                response = ser.read(1).decode("utf-8")
                if not response in self.guessed_letters:
                    self.handle_serial_input(response)
            time.sleep(0.01)

    # function to essentially simulate entering a letter when the letter comes from the FPGA
    def handle_serial_input(self, response):
        if response.isalpha():
            self.guess_entry.insert(0, response)
            self.check_guess()

    # Function to draw the gallow
    def draw_gallow(self):
        self.canvas.create_line(200, 250, 200, 200, fill='black', width=5)
        self.canvas.create_line(200, 200, 100, 200, fill='black', width=5)
        self.canvas.create_line(100, 400, 100, 200, fill='black', width=5)

        # Function to draw the head

    def draw_head(self):
        self.draw_gallow()
        self.canvas.create_oval(180, 250, 220, 300, fill='black')

        # Function to draw the body

    def draw_body(self):
        self.draw_head()
        self.canvas.create_line(200, 300, 200, 350, fill='black', width=5)

        # Function to draw the right arm

    def draw_right_arm(self):
        self.draw_body()
        self.canvas.create_line(200, 325, 225, 350, fill='black', width=5)

        # Function to draw the left arm

    def draw_left_arm(self):
        self.draw_right_arm()
        self.canvas.create_line(200, 325, 175, 350, fill='black', width=5)

        # Function to draw the right leg

    def draw_right_leg(self):
        self.draw_left_arm()
        self.canvas.create_line(200, 350, 225, 400, fill='black', width=5)

        # Function to draw the left leg

    def draw_left_leg(self):
        self.draw_right_leg()
        self.canvas.create_line(200, 350, 175, 400, fill='black', width=5)

    def drawHangman(self):
        self.canvas.delete('all')  # Clear the canvas before drawing
        if self.remaining_guesses == 6:
            self.draw_gallow()
        if self.remaining_guesses == 5:
            self.draw_head()
        if self.remaining_guesses == 4:
            self.draw_body()
        if self.remaining_guesses == 3:
            self.draw_right_arm()
        if self.remaining_guesses == 2:
            self.draw_left_arm()
        if self.remaining_guesses == 1:
            self.draw_right_leg()
        if self.remaining_guesses == 0:
            self.draw_left_leg()
            self.canvas.update()
        self.canvas.update()

    # Method to select a random word from the list of available words
    def select_word(self):
        iterator = 1
        if self.words:  # if the list of words is not empty
            return self.words.pop(random.randint(0, len(self.words) - 1))  # return a random word
        else:
            messagebox.showerror("GAME OVER", "No more words available. Final Score: {} correct out of {}".format(
                self.NumSuccessfulGuesses, self.NumofWords))
            self.master.destroy()
            self.master.quit()  # Close the application
        iterator += 1

    # Method to check the user's guess
    def check_guess(self):
        # if self.remaining_guesses == 0:
        #     # Display message when the user runs out of guesses
        #     self.message_label.config(text="You've run out of guesses. The word was '{}'".format(self.word))
        #     self.guess_button.config(state='disabled')  # Disable the guess button
        #     self.fail_prompt()
        #     # self.restart_prompt()  # Prompt for restart
        #     return

        guess = self.guess_entry.get().lower()

        if guess == '':
            self.message_label.config(text="Please enter a letter.")
        elif len(guess) == 1 and guess.isalpha():  # if it is a single letter
            if guess in self.guessed_letters:  # if it is part of the guessed letters
                self.message_label.config(text="You've already guessed '{}'".format(guess))
            elif guess in self.word:  # if the guess is part of the world
                correctGuesses.append(guess)
                writeToBoard(scrambleToLCD(self.word) + str(self.remaining_guesses))
                for i in range(len(self.word)):
                    if self.word[i] == guess:  # if the guessed letter is in the word
                        self.guesses[i] = guess  # replace the underscore with the guessed letter
                self.word_label.config(
                    text=' '.join(self.guesses))  # updates the mix of guessed letters and underscores
                if '_' not in self.guesses:  # if word has been guessed (no underscores remain)
                    print("guess is right")
                    self.List_With_Removed_Words = self.words
                    print(f"[LWRW]: {self.List_With_Removed_Words}")
                    self.congratulations_prompt()  # Display congratulations messagew
                    self.remove_guessed_word()
            else:
                self.remaining_guesses -= 1
                self.drawHangman()
                if self.remaining_guesses == 0:
                    correctGuesses.clear()
                    # Display message when the user runs out of guesses
                    self.message_label.config(text="You've run out of guesses. The word was '{}'".format(self.word))
                    self.guess_button.config(state='disabled')  # Disable the guess button
                    self.fail_prompt()
                    # self.restart_prompt()  # Prompt for restart
                    return
                self.message_label.config(
                    text="Incorrect guess. {} guess(es) remaining.".format(self.remaining_guesses))
                writeToBoard(scrambleToLCD(self.word) + str(self.remaining_guesses))

            self.guessed_letters.add(guess)
            self.update_guessed_label()  # Update guessed letters display
        else:
            self.message_label.config(text="Invalid input. Please enter a single letter.")

        self.guess_entry.delete(0, 'end')  # Clear the guess entry field

    # Method to display failed message when the user fails the game
    def fail_prompt(self):
        scrollMessage("           Sorry! The correct word was" + ' ' + str(self.word) + ". You have solved " + str(
            self.NumSuccessfulGuesses) + " puzzles out of " + str(self.NumofWords) + ".                 ")

        response = messagebox.showinfo("Game Over",
                                       "Sorry! The correct word was '{}'. You have solved {} puzzle(s) out of {}.".format(
                                           self.word, self.NumSuccessfulGuesses, self.NumofWords))
        if response == 'ok':
            self.restart_prompt()  # Prompt for restart

    # Method to display congratulations message when the user guesses the word
    def congratulations_prompt(self):
        self.NumSuccessfulGuesses += 1
        scrollMessage(
            "                Well done! You have solved " + str(self.NumSuccessfulGuesses) + " puzzles out of " + str(
                self.NumofWords) + ".                        ")

        response = messagebox.showinfo("Congratulations", "Well done! You have solved {} puzzle(s) out of {}.".format(
            self.NumSuccessfulGuesses, self.NumofWords))

        if response == 'ok':
            self.restart_prompt()  # Prompt for restart

    # Method to prompt for restart
    def restart_prompt(self):
        self.master.destroy()  # Close the current GUI window
        prompt = " New Game?               "
        writeToBoard(prompt[::-1])
        root = tk.Tk()  # Open a new GUI window for the new game prompt
        hangman_game = HangmanGame(root, self.NumSuccessfulGuesses, self.List_With_Removed_Words, self.words)
        # print(f"[LWRM]      restart list: {self.List_With_Removed_Words}")
        print(f"[self.words]restart list: {self.words}")
        root.mainloop()

    # Method to update guessed letters display
    def update_guessed_label(self):
        guessed_str = ', '.join(sorted(self.guessed_letters))
        self.guessed_label.config(text='Guessed Letter(s): ' + guessed_str)

    # Method to remove successfully guessed word from the list of available words
    def remove_guessed_word(self):
        if self.word in self.words:
            self.words.remove(self.word)

    # Main function to start the application


def main():
    words = load_words()
    root = tk.Tk()  # Create the root window
    hangman_game = HangmanGame(root, 0, [], words)  # Initialize the game
    root.mainloop()  # Start the main event loop


# Entry point of the application
if __name__ == "__main__":
    main()
