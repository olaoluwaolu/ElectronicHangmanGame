To use this:

1. Make sure to change the COM Port in the python script
2. Program the FPGA using Quartus
3. Run the python script